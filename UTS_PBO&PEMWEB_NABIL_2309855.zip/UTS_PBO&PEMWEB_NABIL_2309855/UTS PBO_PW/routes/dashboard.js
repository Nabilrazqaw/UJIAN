const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const queries = [
    'SELECT COUNT(*) as total_nelayan FROM nelayan',
    'SELECT SUM(weight) as total_biola FROM biola',
    'SELECT SUM(quantity) as total_stock FROM fish_stock',
    'SELECT spesies, SUM(weight) as total_weight FROM biola GROUP BY spesies LIMIT 5'
  ];

  Promise.all(queries.map(query => {
    return new Promise((resolve, reject) => {
      req.db.query(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }))
  .then(([fishermen, biola, stock, topFish]) => {
    res.render('dashboard', {
      user: req.session.user,
      stats: {
        totalFishermen: fishermen[0].total_fishermen,
        totalBiola: biola[0].total_biola || 0,
        totalStock: stock[0].total_stock || 0,
        topFish: topFish
      }
    });
  })
  .catch(err => {
    throw err;
  });
});

module.exports = router;