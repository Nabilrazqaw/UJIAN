const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  req.db.query('SELECT * FROM nelayan', (err, nelayan) => {
    if (err) throw err;
    res.render('nelayan/index', { nelayan, user: req.session.user });
  });
});

router.get('/add', (req, res) => {
  res.render('nelayan/add', { user: req.session.user });
});

router.post('/add', (req, res) => {
  const { name, boat_number, phone } = req.body;
  req.db.query(
    'INSERT INTO nelayan (name, boat_number, phone) VALUES (?, ?, ?)',
    [name, boat_number, phone],
    (err, result) => {
      if (err) throw err;
      res.redirect('/nelayan');
    }
  );
});

router.get('/edit/:id', (req, res) => {
  req.db.query(
    'SELECT * FROM nelayan WHERE id = ?',
    [req.params.id],
    (err, results) => {
      if (err) throw err;
      res.render('nelayan/edit', { fishermen: results[0], user: req.session.user });
    }
  );
});

router.post('/edit/:id', (req, res) => {
  const { name, boat_number, phone } = req.body;
  req.db.query(
    'UPDATE nelayan SET name = ?, boat_number = ?, phone = ? WHERE id = ?',
    [name, boat_number, phone, req.params.id],
    (err, result) => {
      if (err) throw err;
      res.redirect('/nelayan');
    }
  );
});

router.post('/edit/:id', (req, res) => {
  const { name, boat_number, phone } = req.body;
  req.db.query(
    'UPDATE nelayan SET name = ?, boat_number = ?, phone = ? WHERE id = ?',
    [name, boat_number, phone, req.params.id],
    (err, result) => {
      if (err) throw err;
      res.redirect('/nelayan');
    }
  );
});

module.exports = router;