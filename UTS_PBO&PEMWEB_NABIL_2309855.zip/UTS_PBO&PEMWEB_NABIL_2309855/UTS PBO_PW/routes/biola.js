const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  req.db.query(
    `SELECT biola.*, nelayan.name as nelayan_name 
     FROM biola 
     JOIN nelayan ON biola.nelayan_id = nelayan.id`,
    (err, biola) => {
      if (err) throw err;
      res.render('biola/index', { biola, user: req.session.user });
    }
  );
});

router.get('/add', (req, res) => {
  req.db.query('SELECT * FROM nelayan', (err, nelayan) => {
    if (err) throw err;
    res.render('biola/add', { nelayan, user: req.session.user });
  });
});

router.post('/add', (req, res) => {
  const { nelayan_id, lokasi, spesies, weight } = req.body;
  req.db.query(
    'INSERT INTO biola (nelayan_id, lokasi, spesies, weight) VALUES (?, ?, ?, ?)',
    [nelayan_id, lokasi, spesies, weight],
    (err, result) => {
      if (err) throw err;
      res.redirect('/biola');
    }
  );
});

module.exports = router;