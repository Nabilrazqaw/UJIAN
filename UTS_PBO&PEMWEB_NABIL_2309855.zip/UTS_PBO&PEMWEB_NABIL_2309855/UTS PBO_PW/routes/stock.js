// routes/stock.js
const express = require('express');
const router = express.Router();

// Mengambil semua stock ikan
router.get('/', (req, res) => {
  req.db.query('SELECT * FROM fish_stock', (err, stock) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Terjadi kesalahan pada server');
    }
    res.render('stock/index', { stock, user: req.session.user });
  });
});

// Halaman untuk menambah stock ikan
router.get('/add', (req, res) => {
  res.render('stock/add', { user: req.session.user });
});

// Menambahkan stock ikan ke database
router.post('/add', (req, res) => {
  const { spesies, quantity, status } = req.body;

  // Validasi input
  if (!spesies || !quantity || !status) {
    return res.status(400).send('Semua kolom harus diisi.');
  }

  // Menambahkan data ke database
  req.db.query(
    'INSERT INTO fish_stock (spesies, quantity, status) VALUES (?, ?, ?)',
    [spesies, quantity, status],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Terjadi kesalahan saat menambah data stock.');
      }
      res.redirect('/stock');
    }
  );
});

router.get('/edit/:id', (req, res) => {
    const { id } = req.params;
    req.db.query('SELECT * FROM fish_stock WHERE id = ?', [id], (err, stock) => {
      if (err) throw err;
      if (!stock.length) {
        return res.status(404).send('Stock tidak ditemukan');
      }
      res.render('stock/edit', { stock: stock[0], user: req.session.user });
    });
  });
  
  router.post('/edit/:id', (req, res) => {
    const { id } = req.params;
    const { spesies, quantity, status } = req.body;
    req.db.query(
      'UPDATE fish_stock SET spesies = ?, quantity = ?, status = ? WHERE id = ?',
      [spesies, quantity, status, id],
      (err, result) => {
        if (err) throw err;
        res.redirect('/stock');
      }
    );
  });

  router.get('/delete/:id', (req, res) => {
    const { id } = req.params;
    req.db.query('DELETE FROM fish_stock WHERE id = ?', [id], (err, result) => {
      if (err) throw err;
      res.redirect('/stock');
    });
  });
  
  module.exports = router;