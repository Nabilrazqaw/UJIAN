const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const session = require('express-session');
const path = require('path');

// routes
const authRoutes = require('./routes/auth');
const nelayanRoutes = require('./routes/nelayan');
const biolaRoutes = require('./routes/biola');
const stockRoutes = require('./routes/stock');
const dashboardRoutes = require('./routes/dashboard');

const app = express();
const db = require('./config/db'); 

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'ecomarine' 
});

connection.connect((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to database.');
});


// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true
}));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Middleware untuk database terkoneksi
app.use((req, res, next) => {
  req.db = connection;
  next();
});

// Middleware untuk memeriksa sesi pengguna
function checkAuthenticated(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/login');
    }
}

// Auth middleware
const checkAuth = (req, res, next) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  next();
};

// Routes
app.get('/', (req, res) => {
  res.render('index', { user: req.session.user });
});

// 
app.use('/', authRoutes);
app.use('/nelayan', checkAuth, nelayanRoutes);
app.use('/biola', checkAuth, biolaRoutes);
app.use('/stock', checkAuth, stockRoutes);
app.use('/dashboard', checkAuth, dashboardRoutes);

app.listen(3000, () => {
    console.log(`Server is running on http://localhost:3000`);
});