-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2024 at 10:05 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomarine`
--

-- --------------------------------------------------------

--
-- Table structure for table `biola`
--

CREATE TABLE `biola` (
  `id` int(11) NOT NULL,
  `nelayan_id` int(11) NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `spesies` varchar(100) NOT NULL,
  `weight` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `biola`
--

INSERT INTO `biola` (`id`, `nelayan_id`, `lokasi`, `spesies`, `weight`, `price`, `created_at`) VALUES
(1, 1, '0000-00-00', 'napoleon', 50.00, 0.00, '2024-11-12 08:34:59'),
(2, 1, 'perairan atlantik', 'napoleon', 50.00, 0.00, '2024-11-12 08:37:00');

-- --------------------------------------------------------

--
-- Table structure for table `fish_stock`
--

CREATE TABLE `fish_stock` (
  `id` int(11) NOT NULL,
  `spesies` varchar(100) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `status` enum('available','low','out_of_stock') NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fish_stock`
--

INSERT INTO `fish_stock` (`id`, `spesies`, `quantity`, `status`, `updated_at`) VALUES
(1, 'napoleon', 5000.00, 'available', '2024-11-12 08:48:43');

-- --------------------------------------------------------

--
-- Table structure for table `nelayan`
--

CREATE TABLE `nelayan` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `boat_number` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nelayan`
--

INSERT INTO `nelayan` (`id`, `name`, `boat_number`, `phone`, `created_at`) VALUES
(1, 'Nabil', '1234', '085697250185', '2024-11-12 08:11:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'admin', 'admin@upi', '$2b$10$JWdbwRhv.2C.KRHsW2pcEewKjDpo3WX4vg79iTRECl4jhpRrSJWma', '2024-11-12 07:48:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `biola`
--
ALTER TABLE `biola`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nelayan_id` (`nelayan_id`);

--
-- Indexes for table `fish_stock`
--
ALTER TABLE `fish_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nelayan`
--
ALTER TABLE `nelayan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `biola`
--
ALTER TABLE `biola`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fish_stock`
--
ALTER TABLE `fish_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `nelayan`
--
ALTER TABLE `nelayan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `biola`
--
ALTER TABLE `biola`
  ADD CONSTRAINT `biola_ibfk_1` FOREIGN KEY (`nelayan_id`) REFERENCES `nelayan` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
