// cart.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Middleware untuk memastikan user sudah login
const checkAuth = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
};

// Mendapatkan items di keranjang
router.get('/items', checkAuth, (req, res) => {
    const userId = req.session.user.id;
    const query = `
        SELECT ci.*, p.name, p.description, p.image_url, p.price 
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ?
    `;
    
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching cart items:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }
        res.json(results);
    });
});

// Menambah item ke keranjang
router.post('/add', checkAuth, (req, res) => {
    const userId = req.session.user.id;
    const { productId } = req.body;
    
    // Cek apakah item sudah ada di keranjang
    const checkQuery = 'SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?';
    db.query(checkQuery, [userId, productId], (err, results) => {
        if (err) {
            console.error('Error checking cart item:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }
        
        if (results.length > 0) {
            // Update quantity jika item sudah ada
            const updateQuery = `
                UPDATE cart_items 
                SET quantity = quantity + 1 
                WHERE user_id = ? AND product_id = ?
            `;
            db.query(updateQuery, [userId, productId], (updateErr) => {
                if (updateErr) {
                    console.error('Error updating cart item:', updateErr);
                    return res.status(500).json({ error: 'Internal server error' });
                }
                res.json({ message: 'Cart updated successfully' });
            });
        } else {
            // Tambah item baru jika belum ada
            const insertQuery = `
                INSERT INTO cart_items (user_id, product_id) 
                VALUES (?, ?)
            `;
            db.query(insertQuery, [userId, productId], (insertErr) => {
                if (insertErr) {
                    console.error('Error adding cart item:', insertErr);
                    return res.status(500).json({ error: 'Internal server error' });
                }
                res.json({ message: 'Item added to cart successfully' });
            });
        }
    });
});

// Menghapus item dari keranjang
router.delete('/remove/:id', checkAuth, (req, res) => {
    const userId = req.session.user.id;
    const cartItemId = req.params.id;
    
    const query = 'DELETE FROM cart_items WHERE id = ? AND user_id = ?';
    db.query(query, [cartItemId, userId], (err) => {
        if (err) {
            console.error('Error removing cart item:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }
        res.json({ message: 'Item removed successfully' });
    });
});

const getCartTotal = async (userId) => {
    const query = `
        SELECT SUM(p.price * ci.quantity) as total
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ?
    `;
    
    const [result] = await db.query(query, [userId]);
    return result.total || 0;
};

const validateCartItems = async (userId) => {
    const query = `
        SELECT p.id, p.name, p.price, p.stock, ci.quantity
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ?
    `;
    
    const items = await db.query(query, [userId]);
    
    const invalidItems = items.filter(item => item.quantity > item.stock);
    if (invalidItems.length > 0) {
        throw new Error('Some items are out of stock');
    }
    
    return items;
};

module.exports = router;