const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const mongoose = require('mongoose');
const app = express();

// landing
router.get('/landing', (req, res) => {
    res.render('landing');
});

// render halaman register
router.get('/register', (req, res) => {
    res.render('register');
});

// render halaman dashboard
router.get('/dashboard', (req, res) => {
    res.render('dashboard', { user: req.session.user });
});

// render halaman profile
router.get('/profile', (req, res) => {
    res.render('profile', { user: req.session.user });
});

// render halaman login
router.get('/login', (req, res) => {
    res.render('login');
});
// proses logout
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/auth/login');
});


// proses register user
router.post('/register', (req, res) => {
    const { username, password } = req.body;
    
    const hashedPassword = bcrypt.hashSync(password, 10);
    
    const query = "INSERT INTO users (username, password) VALUES (?, ?)";
    // Perbaikan: Menggunakan hashedPassword, bukan password mentah
    db.query(query, [username, hashedPassword], (err, result) => {
        if (err) throw err;
        res.redirect('/auth/login');
    });
});

// proses login user
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    const query = "SELECT * FROM users WHERE username = ?";
    db.query(query, [username], (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            const user = result[0];
            
            if (bcrypt.compareSync(password, user.password)) {
                req.session.user = user;
                res.redirect('/auth/dashboard');
            } else {
                res.send('Incorrect password');
            }
        } else {
            res.send('User not found');
        }
    });
});

// middleware untuk cek autentikasi
const checkAuth = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/auth/login');
    }
};

// render halaman edit profile 
router.get('/edit-profile', (req, res) => {
    res.render('edit-profile', { user: req.session.user });
});


// Rute untuk mengupdate profil (misalnya POST)
router.post('/edit-profile', (req, res) => {
    // Logika untuk memperbarui profil pengguna
    // Misalnya, ambil data dari req.body dan simpan ke database
    // Setelah berhasil, redirect ke profil atau dashboard
    res.redirect('/auth/profile');
});

// render halaman update profile
router.get('/update-profile', (req, res) => {
    const userId = req.session.user.id;
    
    // Mengambil data lengkap user dari database
    const query = "SELECT * FROM users WHERE id = ?";
    db.query(query, [userId], (err, result) => {
        if (err) throw err;
        if (result.length > 0) {
            const userData = result[0];
            res.render('update-profile', { user: userData });
        } else {
            res.redirect('/auth/profile');
        }
    });
});

// proses update profile
router.post('/update-profile', checkAuth, (req, res) => {
    const userId = req.session.user.id;
    const {
        nama,
        tempat_lahir,
        tanggal_lahir,
        jenis_kelamin,
        alamat,
        nomor_telepon,
        agama,
        status_perkawinan,
        pekerjaan,
        kewarganegaraan
    } = req.body;

    const updateQuery = `
        UPDATE users 
        SET 
            nama = ?,
            tempat_lahir = ?,
            tanggal_lahir = ?,
            jenis_kelamin = ?,
            alamat = ?,
            nomor_telepon = ?,
            agama = ?,
            status_perkawinan = ?,
            pekerjaan = ?,
            kewarganegaraan = ?
        WHERE id = ?
    `;

    const values = [
        nama || null,
        tempat_lahir || null,
        tanggal_lahir || null,
        jenis_kelamin || null,
        alamat || null,
        nomor_telepon || null,
        agama || null,
        status_perkawinan || null,
        pekerjaan || null,
        kewarganegaraan || null,
        userId
    ];

    db.query(updateQuery, values, (err, result) => {
        if (err) {
            console.error('Error updating profile:', err);
            res.send('Terjadi kesalahan saat mengupdate profile');
            return;
        }

        // Update session dengan data baru
        req.session.user = {
            ...req.session.user,
            nama,
            tempat_lahir,
            tanggal_lahir,
            jenis_kelamin,
            alamat,
            nomor_telepon,
            agama,
            status_perkawinan,
            pekerjaan,
            kewarganegaraan
        };

        res.redirect('/auth/profile');
    });
});

// render halaman shop dengan daftar produk
router.get('/shop', (req, res) => {
    const query = "SELECT * FROM products"; // Misalnya, ambil data produk dari tabel 'products'
    db.query(query, (err, products) => {
        if (err) throw err;
        res.render('shop', { user: req.session.user, products });
    });
});


// Updated checkout route with proper data handling
router.get('/checkout', checkAuth, async (req, res) => {
    const userId = req.session.user.id;
    
    // Get user profile data
    const userQuery = "SELECT * FROM users WHERE id = ?";
    db.query(userQuery, [userId], (err, userResult) => {
        if (err) {
            console.error('Error fetching user data:', err);
            return res.status(500).send('Internal server error');
        }

        // Get cart items
        const cartQuery = `
            SELECT p.*, ci.quantity 
            FROM cart_items ci
            JOIN products p ON ci.product_id = p.id
            WHERE ci.user_id = ?
        `;
        
        db.query(cartQuery, [userId], (cartErr, cartItems) => {
            if (cartErr) {
                console.error('Error fetching cart items:', cartErr);
                return res.status(500).send('Internal server error');
            }

            res.render('checkout', {
                user: userResult[0] || req.session.user,
                cartItems: cartItems || []
            });
        });
    });
});

// Add new route to handle checkout submission
router.post('/process-checkout', checkAuth, async (req, res) => {
    const userId = req.session.user.id;
    const { shipping, payment, items, total } = req.body;

    try {
        // Start transaction
        await db.beginTransaction();

        // Create order
        const orderQuery = `
            INSERT INTO orders (
                user_id, 
                shipping_method, 
                payment_method, 
                total_amount, 
                status
            ) VALUES (?, ?, ?, ?, 'pending')
        `;
        
        const orderResult = await db.query(
            orderQuery, 
            [userId, shipping, payment, total]
        );
        
        const orderId = orderResult.insertId;

        // Insert order items
        const orderItemQuery = `
            INSERT INTO order_items (
                order_id, 
                product_id, 
                quantity, 
                price
            ) VALUES (?, ?, ?, ?)
        `;
        
        for (const item of items) {
            await db.query(
                orderItemQuery, 
                [orderId, item.id, item.quantity, item.price]
            );
        }

        // Clear cart
        await db.query(
            'DELETE FROM cart_items WHERE user_id = ?', 
            [userId]
        );

        // Commit transaction
        await db.commit();

        res.json({
            success: true,
            orderId: orderId
        });

    } catch (error) {
        // Rollback on error
        await db.rollback();
        console.error('Checkout error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to process checkout'
        });
    }
});

module.exports = router;