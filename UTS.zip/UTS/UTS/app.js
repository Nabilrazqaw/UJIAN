const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const path = require('path');

// Import routes
const authRoutes = require('./routes/auth');
const { name } = require('ejs');
const cartRoutes = require('./routes/cart');


const app = express();

app.set('view engine', 'ejs');

// middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ 
    secret: process.env.SESSION_SECRET || 'default_secret', // Use environment variable for secret
    resave: false,
    saveUninitialized: true
}));

// Set static folder
app.use(express.static(path.join(__dirname, 'public')));


// Middleware to check authentication
app.use((req, res, next) => {
    const publicRoutes = ['/auth/login', '/auth/register', '/'];
    if (req.path === '/') {
        if (req.session.user) {
            return res.redirect('/auth/profile');
        }
        return res.render('landing');
    }
    if (!req.session.user && !publicRoutes.includes(req.path)) {
        return res.redirect('/auth/login');
    }
    next();
});

// Register routes
app.use('/auth', authRoutes);

app.use('/cart', cartRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});

// Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});